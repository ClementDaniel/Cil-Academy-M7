# Group 3 Repo

## Contributors:

- Charity Francis
- Sunday Goodnews
- Daniel Clement
- Solomon Ebigwei
- Onyedika Igwegbe
- Muchiri Nga'nga
- Gabriel Ayetor
- Chris Okolo

This repo contains the files for our group 3 technical challenge. These files include our webapp code, which shows the monitore results and historical data for the Vaulticore sensor.

We used node.js for the backend and javascript for the frontend.
